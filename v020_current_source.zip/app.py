﻿import sys

from PySide6.QtWidgets import QApplication

from src.gui.main_window import MainWindow
from src.version import (
    APP_NAME,
    APP_VERSION,
)


def main():
    app = QApplication(sys.argv)

    app.setApplicationName(
        APP_NAME
    )

    app.setApplicationVersion(
        APP_VERSION
    )

    app.setQuitOnLastWindowClosed(
        False
    )

    start_hidden = (
        "--minimized"
        in sys.argv
    )

    window = MainWindow(
        start_hidden=start_hidden
    )

    if window.start_hidden:
        window.hide()

        window.show_tray_notification(
            "Dota2voice2text запущен "
            "в системном трее."
        )
    else:
        window.show()

    sys.exit(
        app.exec()
    )


if __name__ == "__main__":
    main()
